﻿#pragma once
#include "CGameObject.h"
#include "CProtoMgr.h"
#include "CPlayerBody.h"

enum BODYPART
{
	PART_HEAD,
	PART_BODY,
	PART_LARM,
	PART_RARM,
	PART_LLEG,
	PART_RLEG,
	PART_END
};

class CPlayer : public CGameObject
{
private:
	explicit CPlayer(LPDIRECT3DDEVICE9 pGraphicDev);
	explicit CPlayer(const CGameObject& rhs);
	virtual ~CPlayer();

public:
	virtual			HRESULT		Ready_GameObject();
	virtual			_int		Update_GameObject(const _float& fTimeDelta);
	virtual			void		LateUpdate_GameObject(const _float& fTimeDelta);
	virtual			void		Render_GameObject();

private:
	HRESULT			Add_Component();
	void			Key_Input(const _float& fTimeDelta);
	void			Set_OnTerrain();
	//_vec3			Picking_OnTerrain();
	_vec3			Picking_OnBlock();
	void			Render_Part(BODYPART ePart, _float fAngle , const _matrix& matRootWorld);

private:
	CPlayerBody* m_pBufferCom[PART_END];
	Engine::CTransform* m_pTransformCom;
	Engine::CTexture* m_pTextureCom;
	Engine::CCalculator* m_pCalculatorCom;
	Engine::CCollider* m_pColliderCom;

	//칼
	Engine::CRcTex* m_pSwordBufferCom = nullptr;
	Engine::CTexture* m_pSwordTextureCom = nullptr;

	_matrix m_matRArmWorld;  // 오른팔 정보저장, 칼 위치 등 활용하기 위함

	_vec3				m_vPartOffset[PART_END];
	_vec3				m_vPartScale[PART_END];

	_float				m_fWalkTime;	// 걷기 누적 시간 (사인파 입력)
	_bool				m_bMoving;		// 이동 중 여부

	_vec3 m_vTargetPos;
	bool  m_bHasTarget = false;

	static constexpr float m_fGravity = -20.f;
	static constexpr float m_fJumpPower = 8.f;
	static constexpr float m_fMaxFall = -20.f;

	float m_fVelocityY = 0.f;
	bool m_bOnGround = false;


	//구르기
	bool   m_bRolling = false;
	float  m_fRollTime = 0.f;
	float  m_fRollCooldown = 0.f;

	static constexpr float m_fRollDuration = 0.5f;   
	static constexpr float m_fRollSpeed = 22.f;   
	static constexpr float m_fRollCoolMax = 3.f;    
	_vec3  m_vRollDir; 

private: //중력 적용과 충돌시 위치값 보정
	void Apply_Gravity(const _float& fTimeDelta);
	void Resolve_BlockCollision();


	//구르기
	void Roll_Update(const _float& fTimeDelta);

public:
	static CPlayer* Create(LPDIRECT3DDEVICE9 pGraphicDev);

private:
	virtual void Free();

};